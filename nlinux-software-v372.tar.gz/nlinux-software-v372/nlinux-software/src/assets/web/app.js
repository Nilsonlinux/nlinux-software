// SPDX-License-Identifier: GPL-3.0-or-later
"use strict";

/* ============================== Estado ================================== */
const state = { data: null, cat: "all", q: "", installedOnly: false, busy: false, sysUpdate: null };
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];

/* ============================== i18n ==================================== */
const UI_CODE = (document.documentElement.lang || "pt").split(/[-_]/)[0].toLowerCase();
const UI = (typeof STORE_I18N !== "undefined" && STORE_I18N[UI_CODE]) ||
  (typeof STORE_I18N !== "undefined" && STORE_I18N.pt) || {};
const DATE_LOCALE = UI.dateLocale || "pt-BR";

function tr(key, ...args) {
  let s = UI[key];
  if (s == null) s = key;
  if (args.length) args.forEach((a, i) => { s = s.replace("{" + i + "}", String(a)); });
  return s;
}

// Converte no primeiro boot as strings estáticas do HTML (data-i18n).
function applyStatic() {
  $$("[data-i18n]").forEach((el) => { el.textContent = tr(el.dataset.i18n); });
  $$("[data-i18n-html]").forEach((el) => { el.innerHTML = tr(el.dataset.i18nHtml); });
  $$("[data-i18n-attr]").forEach((el) => {
    el.dataset.i18nAttr.split(",").forEach((pair) => {
      const i = pair.indexOf(":");
      if (i < 0) return;
      el.setAttribute(pair.slice(0, i).trim(), tr(pair.slice(i + 1).trim()));
    });
  });
  document.title = tr("ui.title");
}

// localStorage can be unavailable inside embedded WebKitGTK windows
// (enable-local-storage off by default). Fall back to in-memory storage.
const store = (() => {
  try {
    localStorage.setItem("__nlix_probe", "1");
    localStorage.removeItem("__nlix_probe");
    return localStorage;
  } catch (e) {
    const m = new Map();
    return {
      getItem: (k) => (m.has(k) ? m.get(k) : null),
      setItem: (k, v) => m.set(k, String(v)),
      removeItem: (k) => m.delete(k),
    };
  }
})();

// Report JavaScript errors to the local backend so the native window can be
// debugged from the server log (no browser developer tools inside WebKitGTK).
function reportErr(msg) {
  try {
    fetch("/api/log", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ msg: String(msg).slice(0, 500) }),
    }).catch(() => {});
  } catch (e) { /* ignore */ }
}
window.addEventListener("error", (ev) =>
  reportErr(`${ev.message} @ ${(ev.filename || "").split("/").pop() || "?"}:${ev.lineno || "?"}`));
window.addEventListener("unhandledrejection", (ev) =>
  reportErr(`unhandledrejection: ${(ev.reason && ev.reason.message) || ev.reason || "?"}`));

const CAT_ICONS = {
  all: '<path d="M12 3l2.1 5.6L20 10.5l-5.9 1.9L12 18l-2.1-5.6L4 10.5l5.9-1.9L12 3z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15z"/>',
  accessibility: '<circle cx="12" cy="5" r="2.2"/><path d="M4 8.6h16M12 8.6v5.8m0 0l-3.4 5.6M12 14.4l3.4 5.6"/>',
  accessories: '<path d="M14.3 6.1a3.6 3.6 0 1 0-5 5l-4.6 4.6a1.8 1.8 0 0 0 2.6 2.5l4.6-4.5a3.6 3.6 0 0 0 5-5l-2.3 2.3-2.5-2.5 2.2-2.4z"/><path d="M15.5 8.5 20 4"/>',
  development: '<path d="M7.5 8.5 3.5 12l4 3.5M16.5 8.5l4 3.5-4 3.5M13.2 6l-2.4 12"/>',
  education: '<path d="M2.5 8.2 12 4l9.5 4.2L12 12.4 2.5 8.2z"/><path d="M6.5 10.6v4c0 1.7 2.4 3.2 5.5 3.2s5.5-1.5 5.5-3.2v-4"/><path d="M21.5 8.2v6"/>',
  games: '<rect x="2.5" y="7" width="19" height="10" rx="5"/><path d="M7.5 10v4M5.5 12h4M15 11h.01M17.5 13h.01"/>',
  graphics: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="8.5" cy="9" r="1.6"/><path d="M21 15.5 16 10.5 8 18.5 4.5 15"/>',
  internet: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5a13 13 0 0 1 0 17M12 3.5a13 13 0 0 0 0 17"/>',
  "more-software": '<rect x="3.5" y="3.5" width="7" height="7" rx="2"/><rect x="13.5" y="3.5" width="7" height="7" rx="2"/><rect x="3.5" y="13.5" width="7" height="7" rx="2"/><rect x="13.5" y="13.5" width="7" height="7" rx="2"/>',
  multimedia: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9.5v5l4.5-2.5L10 9.5z"/>',
  office: '<rect x="3" y="7.5" width="18" height="12.5" rx="2.5"/><path d="M8 7.5V6a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1.5M3 12h18"/>',
  server: '<rect x="3" y="4" width="18" height="6.5" rx="2"/><rect x="3" y="13.5" width="18" height="6.5" rx="2"/><path d="M7 7.2h.01M7 16.7h.01"/>',
  system: '<rect x="3" y="4" width="18" height="11.5" rx="2.5"/><path d="M8.5 20h7M12 15.5V20"/>',
};

/* ============================== Utilidades ============================== */
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* Bytes -> texto curto. Base 1024, como o pacman mostra ("59.2 MiB"), mas em
   MB/GB decimais de 1024 também: o número serve para comparar dois programas,
   não para bater com a saída do pacman pacote a pacote.

   Sempre uma casa decimal, e o ",0" final é removido: misturar "2.0 MB" ao
   lado de "423 MB" no mesmo grid deixa o card com aparência de bug. */
function fmtBytes(n) {
  if (!n || n < 0) return "";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = Number(n), i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  if (i === 0) return Math.round(v) + " B";
  return v.toFixed(1).replace(/\.0$/, "") + " " + units[i];
}

function stripTags(html) {
  const tpl = document.createElement("template");
  tpl.innerHTML = String(html ?? "");
  return tpl.content.textContent || "";
}

function sanitize(html) {
  const tpl = document.createElement("template");
  tpl.innerHTML = String(html ?? "");
  const allow = ["B", "I", "U", "EM", "STRONG", "BR", "P", "CODE", "SMALL", "UL", "OL", "LI", "A"];
  for (const el of tpl.content.querySelectorAll("*")) {
    if (!allow.includes(el.tagName)) {
      el.replaceWith(document.createTextNode(el.textContent));
      continue;
    }
    if (el.tagName === "A") {
      const href = el.getAttribute("href") || "";
      if (!/^https?:/i.test(href)) el.removeAttribute("href");
      else { el.target = "_blank"; el.rel = "noopener"; el.className = "m-link"; }
    }
  }
  return tpl.innerHTML;
}

function highlight(text, q) {
  const e = esc(text);
  if (!q) return e;
  const escq = esc(q).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  try { return e.replace(new RegExp("(" + escq + ")", "ig"), "<mark>$1</mark>"); }
  catch { return e; }
}

async function api(path, opts) {
  const res = await fetch(path, opts);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

/* ============================== Toasts =================================== */
function toast(msg, kind = "info", ms = 3400) {
  const box = $("#toasts");
  const el = document.createElement("div");
  el.className = "toast " + kind;
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => {
    el.classList.add("out");
    setTimeout(() => el.remove(), 320);
  }, ms);
}

/* ============================== App icons ================================ */
/* Escape para uso em .card[data-key="..."]: o id vem do catálogo e pode ter
   "/" ou aspas. */
function cssEsc(s) {
  return String(s).replace(/["\\]/g, "\\$&");
}
function mountIcon(img, fallback) {
  img.addEventListener("error", function handler() {
    img.removeEventListener("error", handler);
    const s = document.createElement("span");
    s.className = "icon-fallback";
    s.textContent = (fallback || "?").charAt(0).toUpperCase();
    img.replaceWith(s);
  });
}

/* ============================== Tema ===================================== */
function applyTheme(mode) {
  store.setItem("theme", mode);
  document.documentElement.setAttribute("data-theme", mode);
  renderThemeGlyph();
}

function renderThemeGlyph() {
  const dark = document.documentElement.getAttribute("data-theme") === "dark";
  const ic = $("#theme-ic");
  if (ic) ic.className = dark ? "ti ti-sun" : "ti ti-moon";
  const btn = $("#theme-toggle");
  if (btn) btn.dataset.tip = tr(dark ? "theme.dark" : "theme.light");
}

function themeInit() {
  const cur = document.documentElement.getAttribute("data-theme");
  if (cur !== "light" && cur !== "dark") applyTheme("dark");
  else renderThemeGlyph();
  $("#theme-toggle").addEventListener("click", () => {
    const isDark = document.documentElement.getAttribute("data-theme") === "dark";
    applyTheme(isDark ? "light" : "dark");
  });
}

/* ============================== Header =================================== */
function renderHeader(info) {
  $("#brand-name").textContent = "NLinux";
  $("#foot-info").textContent = tr("foot.apps", info.total);
  // O botão e o selo nascem com `hidden` no HTML, e quem mostra é o payload.
  // Alternar o atributo (e não `style.display`) é o que faz funcionar o
  // padrão: na loja da distro os dois nunca aparecem, nem antes do JS rodar.
  const al = $("#admin-link");
  if (al) al.hidden = !info.admin;
  const ab = $("#admin-badge");
  if (ab) ab.hidden = !info.admin;
  renderRevBadge(info);
  renderStoreMeta(info);
}

/* Revisão do catálogo em uso. Fica no cabeçalho para identificar de relance qual
   versão está instalada: a loja sincroniza sozinha e é este número que muda. */
function renderRevBadge(info) {
  const el = $("#rev-badge");
  if (!el) return;
  const rev = info && info.store && info.store.revision;
  el.textContent = rev == null ? "" : "v" + rev;
  el.hidden = rev == null;
}

function formatStamp(epoch) {
  if (!epoch) return "—";
  const d = new Date(epoch * 1000);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleDateString(DATE_LOCALE) + " " +
    d.toLocaleTimeString(DATE_LOCALE, { hour: "2-digit", minute: "2-digit" });
}

function renderStoreMeta(info) {
  const st = (info && info.store) || {};
  const upd = $("#update-badge");
  if (upd) {
    upd.textContent = tr("upd.badge", formatStamp(st.updated));
    upd.title = tr("update.tip");
  }
}

function renderNet() {
  const el = $("#net-badge");
  if (!el) return;
  const on = navigator.onLine !== false;
  el.classList.toggle("is-offline", !on);
  el.innerHTML = `<i class="ti ${on ? "ti-wifi" : "ti-wifi-off"}"></i> ${on ? tr("net.online") : tr("net.offline")}`;
  el.dataset.tip = on ? tr("net.tipOnline") : tr("net.tipOffline");
}

function openStoreInfo() {
  const info = state.data || {};
  const st = info.store || {};
  const rows = [
    [tr("storeinfo.version"), st.revision ? `v${st.revision}` : "—",
      st.version ? tr("storeinfo.catalogFormat", st.version) : ""],
    [tr("storeinfo.author"), st.author || "—", ""],
    [tr("storeinfo.lastUpdate"), formatStamp(st.updated), ""],
    [tr("storeinfo.apps"), String(info.total != null ? info.total : "—"), ""],
  ].map(([k, v, hint]) =>
    `<div><dt>${k}</dt><dd>${esc(v)}${hint ? `<span class="m-hint">${esc(hint)}</span>` : ""}</dd></div>`
  ).join("");
  $("#modal-content").innerHTML = `
    <h2>${tr("storeinfo.title")}</h2>
    <p class="m-desc">${info.total != null ? tr("storeinfo.appsCount", info.total) : ""} ${tr("storeinfo.curation", esc(st.author || "NLinux"))}</p>
    <div class="meta">${rows}</div>
    <div class="actions">
      <a class="btn btn-ghost" href="${esc(st.repo || "#")}" target="_blank" rel="noopener"><i class="ti ti-brand-github"></i> ${tr("storeinfo.repo")}</a>
      <button class="btn btn-primary" data-close><i class="ti ti-check"></i> ${tr("ui.close")}</button>
    </div>`;
  $("#modal").hidden = false;
}

/* ============================== Categorias =============================== */
function renderCats(cats) {
  const nav = $("#cats");
  const list = [{ id: "all", count: state.data.total }, ...cats];
  const installedCount = state.data.products.filter((p) => p.installed).length;
  const chaves = list.map((c) => c.id).join("|");

  /* Só as contagens mudam na maioria das atualizações: manter os botões no
     lugar evita refazer a linha inteira (e a animação dela) a cada revisão. */
  if (nav.dataset.chaves === chaves) {
    const fc = nav.querySelector("[data-installed-filter] b");
    if (fc) fc.textContent = installedCount;
    list.forEach((c) => {
      const b = nav.querySelector(`[data-cat="${cssEsc(c.id)}"]`);
      if (b) {
        const n = b.querySelector("b");
        if (n) n.textContent = c.count;
        b.classList.toggle("active", c.id === state.cat);
      }
    });
    return;
  }

  const installedFilter = `<button class="cat cat-installed${state.installedOnly ? " active" : ""}" data-installed-filter aria-pressed="${state.installedOnly}">
    <i class="ti ti-circle-check"></i><span>${tr("filter.installed")}</span><b id="installed-filter-count">${installedCount}</b>
  </button>`;
  nav.dataset.chaves = chaves;
  nav.innerHTML = installedFilter + list.map((c, i) => {
    const label = UI["cat." + c.id] || c.id;
    return `<button class="cat ${c.id === state.cat ? "active" : ""}" data-cat="${c.id}" style="animation:fadeUp .4s ${i * 25}ms both">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${CAT_ICONS[c.id] || CAT_ICONS.all}</svg>
      <span>${label}</span><b>${c.count}</b>
    </button>`;
  }).join("");
  nav.querySelector("[data-installed-filter]").addEventListener("click", (ev) => {
    state.installedOnly = !state.installedOnly;
    ev.currentTarget.classList.toggle("active", state.installedOnly);
    ev.currentTarget.setAttribute("aria-pressed", String(state.installedOnly));
    render(true);
  });
  nav.querySelectorAll("[data-cat]").forEach((b) =>
    b.addEventListener("click", () => {
      state.cat = b.dataset.cat;
      nav.querySelectorAll("[data-cat]").forEach((x) => x.classList.toggle("active", x === b));
      render(true);
    })
  );
}

/* ============================== Grid ===================================== */
function skeletonCards(n = 8) {
  $("#grid").innerHTML = Array.from({ length: n }, () =>
    '<div class="skeleton"><div class="sk-line sk-ic"></div><div class="sk-line sk-t1"></div><div class="sk-line sk-t2"></div><div class="sk-line sk-t3"></div></div>').join("");
}

function visibleProducts() {
  const q = state.q.trim().toLowerCase();
  const qs = q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = qs ? new RegExp(qs, "i") : null;
  return state.data.products.filter((p) => {
    if (state.cat !== "all" && p.category !== state.cat) return false;
    if (state.installedOnly && !p.installed) return false;
    if (!re) return true;
    return re.test(p.name) || re.test(p.id || "") || re.test(p.summary) || re.test(p.description) ||
           re.test(p.developer || "") || re.test(p.category);
  });
}

/* Uma ação só por app: "Instalar" quando não está instalado, "Remover" quando
   está. Não existe "Reinstalar": quem está instalado sai pelo mesmo botão. */
function actionHtml(p, tip) {
  const dis = state.busy ? "disabled" : "";
  if (p.installed) {
    if (!p.packages.length) return "";
    const dica = tip || tr("tip.remove", esc(p.packages.join(", ")));
    return `<button class="btn btn-ghost btn-remove tip" data-action="remove" data-key="${esc(p.key)}" data-tip="${dica}" ${dis}><i class="ti ti-trash"></i> ${tr("ui.remove")}</button>`;
  }
  if (p.source === "manual") {
    if (p.website) return `<a class="btn btn-ghost" href="${esc(p.website)}" target="_blank" rel="noopener"><i class="ti ti-external-link"></i> ${tr("src.manual")}</a>`;
    return `<button class="btn btn-ghost" disabled><i class="ti ti-tools"></i> ${tr("ui.manual")}</button>`;
  }
  const dica = tip || tr("tip.package", esc(p.packages.join(", ")));
  return `<button class="btn btn-primary btn-install tip" data-action="install" data-key="${esc(p.key)}" data-tip="${dica}" ${dis}><i class="ti ti-download"></i> ${tr("ui.install")}</button>`;
}

function cardActionHtml(p) {
  return actionHtml(p);
}

/* Rótulo do repositório de origem. `core` e `extra` são o Arch oficial; `aur`
   é a comunidade. Quando o repositório não veio (pacote manual, ou app de AUR
   que não tem repo porque não é dos repositórios), cai no rótulo antigo. */
/* Repositório de origem. Core e Extra são oficiais mas têm cores distintas, e
   o multiblib também é oficial — sem o caso dele, o Steam (que só existe lá)
   cairia no genérico "Oficial" e pareceria igual a um app de qualquer repo.
   Uma fonte manual não tem repositório: mostra o site oficial. */
function repoChip(p) {
  if (p.source === "manual") return `<span class="chip">${UI["src.manual"] || "manual"}</span>`;
  if (p.source === "aur") {
    return `<span class="chip chip-repo-aur" data-tip="${esc(tr("tip.repoAUR"))}">${UI["src.aur"] || "AUR"}</span>`;
  }
  if (p.repo === "core") return `<span class="chip chip-repo-core">${tr("chip.repoCore")}</span>`;
  if (p.repo === "extra") return `<span class="chip chip-repo-extra">${tr("chip.repoExtra")}</span>`;
  if (p.repo === "multilib") {
    return `<span class="chip chip-repo-multilib">${tr("chip.repoMultilib")}</span>`;
  }
  return `<span class="chip chip-official">${tr("chip.official")}</span>`;
}

/* Tamanho instalado, ao lado do repositório. Só aparece com número real: sem
   dado do pacman, é melhor não mostrar nada do que mostrar "—" ou 0 MB. O
   %ISIZE% falta em alguns pacotes do banco; o %CSIZE% quase sempre está. Nesses
   casos o card mostra o tamanho de download — com a dica dizendo que é só de
   download, senão a pessoa compara o número com os vizinhos e conclui que o
   programa ocupa aquilo no disco. */
function sizeChip(p) {
  if (!p.size && !p.download) return "";
  const soDownload = !p.size;
  const valor = soDownload ? fmtBytes(p.download) : fmtBytes(p.size);
  const tip = soDownload
    ? tr("tip.sizeDownload", valor)
    : (p.download
      ? tr("tip.sizeBoth", valor, fmtBytes(p.download))
      : tr("tip.sizeOnly", valor));
  return `<span class="chip chip-size tip" data-tip="${esc(tip)}">` +
    `<i class="ti ti-package"></i>${esc(valor)}</span>`;
}

/* O pacote que o catálogo pede, para o aviso poder nomear. `declared` vem do
   servidor justamente para o caso de nome inválido: quando o pacman recusa o
   nome (steam:i386), `packages` fica vazio e o aviso sem este campo diria
   "o pacote “” não existe mais".

   `missing_hint` é o diagnóstico do servidor, que conhece a diferença entre
   "saiu do Arch" e "nunca foi um nome válido". Sem ele o texto mente para o
   Steam: `steam:i386` não deixou de existir, nunca existiu assim. */
function missingChip(p) {
  if (!p.missing && !p.aur_missing) return "";
  const what = p.declared || (p.packages && p.packages[0]) || "";
  const dica = p.aur_missing
    ? tr("tip.aurMissing", what)
    : (p.missing_hint
      ? (what ? `${what} — ${p.missing_hint}` : p.missing_hint)
      : (what ? tr("tip.pkgMissing", what) : tr("chip.pkgMissing")));
  return `<span class="chip chip-missing tip" data-tip="${esc(dica)}">` +
    `${esc(tr("chip.pkgMissing"))}</span>`;
}

function renamedChip(p) {
  if (!p.renamed || p.missing || p.aur_missing) return "";
  return `<span class="chip chip-renamed tip" data-tip="${esc(tr("tip.pkgRenamed", p.renamed_to))}">` +
    `${esc(tr("chip.pkgRenamed"))}</span>`;
}

function chipFor(p) {
  return repoChip(p) + sizeChip(p) + renamedChip(p) + missingChip(p);
}

function cardHtml(p, i) {
  const installedChip = p.installed
    ? `<span class="installed-chip">${tr("installed.chip")}</span>` : "";
  const chip = chipFor(p);
  return `
  <article class="card" data-key="${esc(p.key)}" style="--i:${Math.min(i, 18)}">
    ${installedChip}
    <div class="card-top">
      <div class="icon-wrap">
        <img src="${esc(p.icon)}" alt="" loading="lazy" data-fb="${esc(p.name)}">
      </div>
      <div>
        <h3>${highlight(p.name, state.q)}</h3>
        <p class="dev">${esc(p.developer || "")}</p>
      </div>
    </div>
    <div class="desc">${highlight(stripTags(p.description), state.q)}</div>
    ${chip ? `<div class="chip-row">${chip}</div>` : ""}
    <div class="actions">
      <button class="btn btn-ghost" data-action="details" data-key="${esc(p.key)}"><i class="ti ti-info-circle"></i> ${tr("ui.details")}</button>
      ${cardActionHtml(p)}
    </div>
  </article>`;
}

function render(animate = true) {
  const grid = $("#grid");
  const products = visibleProducts();
  $("#installed-filter-count").textContent =
    state.data.products.filter((p) => p.installed).length;
  $("#results-count").textContent = tr("results.count", products.length, state.data.total);
  $("#empty").hidden = products.length > 0;

  grid.innerHTML = products.map(cardHtml).join("");
  state.cardSig = new Map(products.map((p) => [p.key, cardSig(p)]));
  grid.querySelectorAll("img").forEach((img) => mountIcon(img, img.dataset.fb));
  if (!animate) {
    grid.querySelectorAll(".card").forEach((c) => (c.style.animation = "none"));
  }
}

/* ============================== Modal ==================================== */

/* O banco do pacman às vezes tem só um dos dois tamanhos: o %ISIZE% falta em
   uns pacotes e o %CSIZE% em outros. São três textos separados porque juntar os
   casos num texto só deixaria um separador órfão na tela
   ("423 MB instalado ·  de download"). Sem nenhum número, string vazia — e o
   modal não mostra a linha. */
function modalSizeText(product) {
  if (product.size && product.download) {
    return tr("modal.sizeFull", fmtBytes(product.size), fmtBytes(product.download));
  }
  if (product.size) return tr("modal.sizeOnly", fmtBytes(product.size));
  if (product.download) return tr("modal.sizeDownloadOnly", fmtBytes(product.download));
  return "";
}

function openModal(product) {
  $("#modal").hidden = false;
  const desc = sanitize(product.description);
  const srcChip = repoChip(product) + sizeChip(product) +
    renamedChip(product) + missingChip(product);
  const sizeText = modalSizeText(product);
  const sizeLine = sizeText
    ? `<div><dt>${tr("modal.size")}</dt><dd>${esc(sizeText)}` +
      `${product.pkgversion ? ` <span class="m-ver">${esc(product.pkgversion)}</span>` : ""}</dd></div>`
    : "";
  const meta = `
    <div class="meta">
      <div><dt>${tr("modal.license")}</dt><dd>${product.proprietary ? tr("modal.proprietaryLicense") : tr("modal.openSource")}</dd></div>
      <div><dt>${tr("modal.platform")}</dt><dd>${product.arches.map((a) =>
        `<span class="${a === state.data.system.arch ? "arch-cur" : "arch-oth"}">${a}</span>`).join("")}</dd></div>
      <div><dt>${tr(product.packages.length > 1 ? "modal.packages" : "modal.package")}</dt><dd class="m-pkgs">${esc(product.packages.join(", "))}</dd></div>
      <div><dt>${tr("modal.source")}</dt><dd class="m-src">${srcChip}</dd></div>
      ${sizeLine}
      <div><dt>${tr("modal.developer")}</dt><dd>${esc(product.developer || "—")}</dd></div>
    </div>`;
  const gallery = product.screenshots.length
    ? `<div class="gallery"><h4>${tr("modal.screenshots")}</h4><div class="gallery-strip">${product.screenshots.map((s, i) =>
        `<img src="${esc(s)}" alt="${tr("modal.capture", i + 1)}" loading="lazy" data-gallery="${esc(product.key)}" data-i="${i}">`).join("")}</div></div>`
    : `<p class="no-gallery">${tr("modal.noScreenshots")}</p>`;

  $("#modal-content").innerHTML = `
    <div class="m-head">
      <div class="m-icon"><img src="${esc(product.icon)}" alt="" data-fb="${esc(product.name)}"></div>
      <div class="m-titles">
        <h2>${esc(product.name)}</h2>
        <p class="m-dev">${esc(product.developer || "")}</p>
        <p class="m-sum">${esc(product.summary)}</p>
        <div class="m-actions">${modalActionsHtml(product)}</div>
      </div>
    </div>
    <div class="m-body"><p>${desc}</p></div>
    ${meta}
    ${gallery}`;
  $("#modal-content").querySelectorAll("img").forEach((img) => mountIcon(img, img.dataset.fb));

  $("#modal-content").querySelectorAll("[data-action=more-screens]").forEach((a) =>
    a.addEventListener("click", () => openLightbox(product, 0)));
  $("#modal-content").querySelectorAll(".gallery-strip img").forEach((img) =>
    img.addEventListener("click", () => openLightbox(product, +img.dataset.i)));
  bindModalActions(true);
}

function modalActionsHtml(p) {
  if (p.source !== "arch") {
    if (p.source === "aur") {
      const url = `https://aur.archlinux.org/packages/${encodeURIComponent(p.packages[0] || "")}`;
      return `<a class="btn btn-ghost tip" data-tip="${tr("tip.aurPage")}" href="${esc(url)}" target="_blank" rel="noopener"><i class="ti ti-package"></i> AUR</a>` +
        actionHtml(p, tr("tip.aurPkgs", esc(p.packages.join(", "))));
    }
    if (p.website) return `<a class="btn btn-primary" href="${esc(p.website)}" target="_blank" rel="noopener"><i class="ti ti-external-link"></i> ${tr("src.manual")}</a>`;
    return `<button class="btn btn-primary" disabled><i class="ti ti-alert-triangle"></i> ${tr("ui.noPackage")}</button>`;
}
  return actionHtml(p);
}

function fromKey(key) {
  return state.data.products.find((p) => p.key === key);
}

/* ============================== Lightbox ================================= */
let lbKey = null, lbIdx = 0;
function openLightbox(product, idx) {
  const shots = product.screenshots;
  if (!shots.length) return;
  lbKey = product.key; lbIdx = idx;
  $("#lightbox-img").src = shots[idx];
  $("#lightbox").hidden = false;
}
function lbStep(d) {
  const p = fromKey(lbKey);
  if (!p || !p.screenshots.length) return;
  lbIdx = (lbIdx + d + p.screenshots.length) % p.screenshots.length;
  $("#lightbox-img").src = p.screenshots[lbIdx];
}

/* ============================== Instalação =============================== */
function statusCard(title, line, mode, progress = null) {
  const sc = $("#install-status");
  sc.hidden = false;
  sc.classList.toggle("done", mode === "done");
  sc.classList.toggle("error", mode === "error");
  $("#status-title").textContent = title;
  $("#status-line").textContent = line || "";
  const bar = $("#status-bar");
  if (progress === null) {
    bar.style.removeProperty("width");
    bar.style.removeProperty("animation");
  } else {
    bar.style.width = `${Math.max(0, Math.min(100, progress))}%`;
    bar.style.animation = "none";
  }
}

function updateJobReply(formId, waiting, jobId) {
  const form = $(formId);
  if (!form) return;
  const wasHidden = form.hidden;
  form.dataset.jobId = jobId || "";
  form.hidden = !waiting;
  if (waiting && wasHidden) form.querySelector("input")?.focus();
}

async function sendJobReply(event) {
  event.preventDefault();
  const form = event.target.closest("[data-job-reply]");
  const input = form?.querySelector("input");
  const button = form?.querySelector("button");
  const text = input?.value.trim();
  if (!form || !text || !form.dataset.jobId) return;
  if (button) button.disabled = true;
  try {
    await api("/api/answer", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: form.dataset.jobId, text }),
    });
    input.value = "";
    form.hidden = true;
  } catch (error) {
    toast(error.message || tr("toast.failUpdate"), "err");
  } finally {
    if (button) button.disabled = false;
  }
}

function updateInstallButtons(product, progress, mode, running = true) {
  const verb = (mode === "remove" ? tr("status.uninstalling") : tr("status.installing"))
    .replace(/…$/, "").trim();
  const label = running
    ? Number.isFinite(progress) ? `${verb} ~${progress}%` : `${verb}…`
    : product.installed ? tr("ui.remove") : tr("ui.install");
  /* O botão que mostra o progresso é o da ação em andamento: desinstalar também
     precisa aparecer na tela, senão a barra de status é a única pista. */
  const emAndamento = running && mode === "remove" ? "remove" : "install";
  $$(`[data-action=${emAndamento}]`)
    .filter((button) => button.dataset.key === product.key)
    .forEach((button) => {
      const icon = document.createElement("i");
      icon.className = running && mode === "remove" ? "ti ti-trash" : "ti ti-download";
      button.replaceChildren(icon, document.createTextNode(` ${label}`));
      button.classList.toggle("is-running", running);
      button.setAttribute("aria-label", label);
    });
}

function setBusy(busy) {
  state.busy = busy;
  $$("#grid [data-action=install], #grid [data-action=remove]").forEach((b) => (b.disabled = busy));
}

function startRemove(product, btn) {
  if (state.busy) { toast(tr("toast.busy"), "info"); return; }
  if (!product.packages.length) { toast(tr("toast.noPackages"), "err"); return; }
  const modal = $("#modal");
  $("#modal-content").innerHTML = `
    <h2>${tr("confirm.title", esc(product.name))}</h2>
    <p class="m-desc">${tr("confirm.desc", esc(product.packages.join(", ")))}</p>
    <div class="actions">
      <button class="btn btn-ghost" data-close>${tr("ui.cancel")}</button>
      <button class="btn btn-primary btn-remove" id="confirm-remove"><i class="ti ti-trash"></i> ${tr("ui.uninstall")}</button>
    </div>`;
  modal.hidden = false;
  const confirmBtn = $("#confirm-remove");
  if (confirmBtn) confirmBtn.addEventListener("click", () => {
    modal.hidden = true;
    startInstall(product, btn, "remove");
  });
}

async function startInstall(product, btn, mode = "install") {
  if (state.busy) { toast(tr("toast.busyInstall"), "info"); return; }
  if (!product.packages.length) { toast(tr("toast.noPackages"), "err"); return; }

  const removing = mode === "remove";
  const gerund = removing ? tr("status.uninstalling").replace(/…$/, "") : tr("status.installing").replace(/…$/, "");
  state.busy = true;
  setBusy(true);
  const card = btn.closest(".card");
  if (card) card.classList.add("installing-card");
  updateInstallButtons(product, null, mode);

  statusCard(`${gerund} ${product.name}…`, tr("status.waiting"), "");

  let job;
  try {
    job = await api("/api/install", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ packages: product.packages, source: product.source, action: mode }),
    });
  } catch (e) {
    finishInstall(false, product, btn, card, mode);
    updateInstallButtons(product, null, mode, false);
    toast(removing ? tr("toast.startFailUninstall") : tr("toast.startFailInstall"), "err");
    return;
  }

  let currentProgress = null;
  (async function poll() {
    const st = await api("/api/status?id=" + job.id).catch(() => null);
    if (!st) {
      updateInstallButtons(product, currentProgress, mode);
      statusCard(`${gerund} ${product.name}…`, tr("status.checking"), "", currentProgress);
      setTimeout(poll, 1400);
    }
    else if (st.state === "pending") {
      currentProgress = Number.isFinite(st.progress)
        ? Math.max(currentProgress ?? 0, Math.min(99, st.progress))
        : null;
      const waiting = st.lines.length <= 1;
      const last = waiting
        ? tr("status.waiting")
        : st.lines[st.lines.length - 1];
      updateJobReply("#install-reply", !!st.esperando_resposta, job.id);
      updateInstallButtons(product, currentProgress, mode);
      statusCard(`${gerund} ${product.name}…`, last, "", currentProgress);
      setTimeout(poll, 1400);
    } else {
      updateJobReply("#install-reply", false, job.id);
      const ok = st.done && st.success;
      finishInstall(ok, product, btn, card, mode);
      updateInstallButtons(product, 100, mode, false);
      if (ok) {
        const last = st.lines[st.lines.length - 1] || "";
        statusCard(removing
          ? tr("status.uninstalled", product.name)
          : tr("status.installed", product.name), last, "done");
        toast(removing
          ? tr("toast.successUninstall", product.name)
          : tr("toast.successInstall", product.name), "succ");
      } else {
        const last = st.lines[st.lines.length - 1] || "";
        statusCard(removing
          ? tr("status.failUninstall", product.name)
          : tr("status.failInstall", product.name), last, "error");
        toast(removing
          ? tr("toast.failUninstall", product.name)
          : tr("toast.failInstall", product.name), "err");
      }
      setTimeout(() => { $("#install-status").hidden = true; }, 4200);
    }
  })();
}

function finishInstall(ok, product, btn, card, mode = "install") {
  btn.classList.remove("is-running");
  if (card) card.classList.remove("installing-card");
  if (ok) {
    const p = fromKey(product.key);
    if (p) p.installed = mode !== "remove";
  }
  state.busy = false;
  setBusy(false);
  conferirDoServidor(product);
}

/* ============================== Delegation =============================== */
function bindDelegates() {
  $("#grid").addEventListener("click", (ev) => {
    const btn = ev.target.closest("[data-action]");
    if (!btn) return;
    const product = fromKey(btn.dataset.key);
    if (!product) return;
    if (btn.dataset.action === "install") startInstall(product, btn);
    else if (btn.dataset.action === "remove") startRemove(product, btn);
    else if (btn.dataset.action === "details") openModal(product);
  });

  $("#grid").addEventListener("click", (ev) => {
    const wrap = ev.target.closest(".icon-wrap");
    if (!wrap) return;
    const card = ev.target.closest(".card");
    if (card) openModal(fromKey(card.dataset.key));
  });
}

function bindModalActions() {
  const content = $("#modal-content");
  content.querySelectorAll("[data-action=install]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const product = fromKey(btn.dataset.key);
      if (product) startInstall(product, btn);
    }));
  content.querySelectorAll("[data-action=remove]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const product = fromKey(btn.dataset.key);
      if (product) startRemove(product, btn);
    }));
}

function openSysUpdatesModal() {
  renderSysUpdatesModal(!!state.sysUpdate?.active);
}

function renderSysUpdatesModal(showProgress) {
  const updates = state.updates || {};
  const pacotes = updates.pacotes || [];
  if (pacotes.length === 0 && !showProgress) return;

  $("#modal").hidden = false;
  const sizeInfo = updates.sized === updates.total && updates.total_bytes
    ? `<div><dt>${tr("sysupd.modal.size")}</dt><dd>${esc(fmtBytes(updates.total_bytes))}</dd></div>`
    : "";
  const restartInfo = updates.reiniciar
    ? `<div class="alert alert-warning"><i class="ti ti-alert-circle"></i> ${tr("sysupd.modal.restart")}</div>`
    : "";
  const pacotesList = pacotes
    .map((p) => `<li><span class="ver-from">${esc(p.pacote)}</span><span class="ver-arrow">→</span><span class="ver-to">${esc(p.para)}</span></li>`)
    .join("");
  const sysUpdate = showProgress ? state.sysUpdate : null;
  const progressMarkup = sysUpdate
    ? `<section class="sysupd-output" aria-live="polite">
        <div class="sysupd-ring-wrap" role="img" aria-label="${tr("status.updating")}">
          <svg class="sysupd-ring" viewBox="0 0 200 200" aria-hidden="true">
            <defs>
              <linearGradient id="sysupd-ring-gradient" gradientUnits="userSpaceOnUse" x1="12" y1="100" x2="188" y2="100">
                <stop offset="0" stop-color="#0d5ad6"/>
                <stop offset=".42" stop-color="#17a2d3"/>
                <stop offset=".5" stop-color="#b7f2ff"/>
                <stop offset=".58" stop-color="#17a2d3"/>
                <stop offset="1" stop-color="#0d5ad6"/>
              </linearGradient>
            </defs>
            <circle class="sysupd-ring-bg" cx="100" cy="100" r="88"/>
            <circle id="sysupd-ring-fg" class="sysupd-ring-fg" cx="100" cy="100" r="88"/>
            <circle class="sysupd-ring-loader" cx="100" cy="100" r="88"/>
          </svg>
          <div class="sysupd-ring-center"><span id="sysupd-ring-pct">0%</span></div>
        </div>
        <h4>${tr("sysupd.modal.logs")}</h4>
        <pre id="sysupd-log" class="sysupd-log"></pre>
        <form class="job-reply" id="sysupd-reply" data-job-reply hidden>
          <label for="sysupd-reply-text">${tr("sysupd.modal.reply")}</label>
          <div><input id="sysupd-reply-text" type="text" autocomplete="off" required>
          <button class="btn btn-primary" type="submit"><i class="ti ti-send"></i> ${tr("sysupd.modal.send")}</button></div>
        </form>
      </section>`
    : "";
  const buttonLabel = sysUpdate
    ? (sysUpdate.active ? tr("status.updating") : tr("ui.close"))
    : tr("sysupd.modal.button");
  const buttonIcon = sysUpdate
    ? (sysUpdate.active ? "ti-refresh" : "ti-check")
    : "ti-download";
  const buttonState = sysUpdate?.active ? "disabled" : "";
  const closeAction = sysUpdate && !sysUpdate.active ? "data-close" : "";

  $("#modal-content").innerHTML = `
    <div class="m-head">
      <div class="m-titles">
        <h2><i class="ti ti-refresh"></i> ${tr("sysupd.modal.title")}</h2>
        <p class="m-sum">${tr("sysupd.tipFull", updates.total, fmtBytes(updates.total_bytes || 0))}</p>
      </div>
    </div>
    <div class="m-body">
      ${restartInfo}
      <div class="meta">
        <div><dt>${tr("results.count", updates.total, updates.total)}</dt></div>
        ${sizeInfo}
      </div>
      <div class="packages-list">
        <details class="packages-details">
          <summary><span><i class="ti ti-package"></i> ${tr("modal.packages")} (${pacotes.length})</span><i class="ti ti-chevron-down packages-chevron"></i></summary>
          <ul class="pkg-list">${pacotesList}</ul>
        </details>
      </div>
      ${progressMarkup}
    </div>
    <div class="m-actions">
      <button class="btn btn-primary" id="sysupd-install-btn" ${buttonState} ${closeAction}><i class="ti ${buttonIcon}"></i> ${buttonLabel}</button>
    </div>`;

  if (sysUpdate) updateSysUpdateModal();
  const installBtn = $("#sysupd-install-btn");
  if (installBtn && !sysUpdate) installBtn.addEventListener("click", startSysUpdate);
}

function updateSysUpdateModal() {
  const job = state.sysUpdate;
  if (!job) return;
  updateJobReply("#sysupd-reply", !!job.waitingForAnswer, job.id);
  const log = $("#sysupd-log");
  if (log) {
    log.textContent = (job.lines || []).join("\n");
    log.scrollTop = log.scrollHeight;
  }
  paintSysUpdateRing(Number.isFinite(job.ringPct) ? job.ringPct : 0);
  const button = $("#sysupd-install-btn");
  if (button && !job.active) {
    button.disabled = false;
    button.setAttribute("data-close", "");
    const icon = document.createElement("i");
    icon.className = "ti ti-check";
    button.replaceChildren(icon, document.createTextNode(` ${tr("ui.close")}`));
  }
}

function paintSysUpdateRing(progress) {
  const ring = $("#sysupd-ring-fg");
  const label = $("#sysupd-ring-pct");
  if (!ring || !label) return;
  const pct = Math.max(0, Math.min(100, progress));
  label.textContent = Math.round(pct) + "%";
  ring.style.strokeDashoffset = String(553 - (553 * pct) / 100);
}

function tweenSysUpdateRing(progress) {
  const job = state.sysUpdate;
  if (!job) return;
  const target = Number.isFinite(progress)
    ? Math.max(0, Math.min(100, progress))
    : (Number.isFinite(job.ringPct) ? job.ringPct : 0);
  if (job.ringFrame != null) cancelAnimationFrame(job.ringFrame);
  let current = Number.isFinite(job.ringPct) ? job.ringPct : 0;
  const frame = () => {
    const diff = target - current;
    if (Math.abs(diff) <= 0.5) {
      current = target;
      job.ringFrame = null;
    } else {
      current += diff * 0.35;
      job.ringFrame = requestAnimationFrame(frame);
    }
    job.ringPct = current;
    paintSysUpdateRing(current);
  };
  frame();
}

async function startSysUpdate() {
  if (state.busy) { toast(tr("toast.busyInstall"), "info"); return; }
  state.busy = true;
  setBusy(true);
  state.sysUpdate = { active: true, lines: [tr("status.waiting")], progress: null };
  renderSysUpdatesModal(true);
  renderSysUpdateProgress(null);
  statusCard(`${tr("status.updating").replace(/…$/, "")}…`, tr("status.waiting"), "");

  let job;
  try {
    job = await api("/api/sysupdate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
    });
  } catch (e) {
    state.busy = false;
    setBusy(false);
    let detail = e.message || tr("toast.startFailUpdate");
    try {
      const response = JSON.parse(detail);
      detail = [response.error, response.detalhe].filter(Boolean).join(": ") || detail;
    } catch (_) { /* resposta não estruturada */ }
    state.sysUpdate = { active: false, success: false, lines: [detail] };
    renderSysUpdatesModal(true);
    renderSysUpdates(state.updates || {});
    toast(detail, "err");
    return;
  }
  state.sysUpdate.id = job.id;

  let currentProgress = null;
  (async function poll() {
    const st = await api("/api/status?id=" + job.id).catch(() => null);
    if (!st) {
      state.sysUpdate.lines = [tr("status.checking")];
      updateSysUpdateModal();
      renderSysUpdateProgress(currentProgress);
      statusCard(`${tr("status.updating").replace(/…$/, "")}…`, tr("status.checking"), "", currentProgress);
      setTimeout(poll, 1400);
    }
    else if (st.state === "pending") {
      currentProgress = Number.isFinite(st.progress)
        ? Math.max(currentProgress ?? 0, Math.min(99, st.progress))
        : null;
      state.sysUpdate.lines = st.lines || [];
      state.sysUpdate.progress = currentProgress;
      state.sysUpdate.waitingForAnswer = !!st.esperando_resposta;
      updateSysUpdateModal();
      renderSysUpdateProgress(currentProgress);
      const waiting = st.lines.length <= 1;
      const last = waiting ? tr("status.waiting") : st.lines[st.lines.length - 1];
      statusCard(`${tr("status.updating").replace(/…$/, "")}…`, last, "", currentProgress);
      setTimeout(poll, 1400);
    } else {
      const ok = st.done && st.success;
      state.sysUpdate.active = false;
      state.sysUpdate.success = ok;
      state.sysUpdate.lines = st.lines || [];
      state.sysUpdate.waitingForAnswer = false;
      updateSysUpdateModal();
      if (ok) tweenSysUpdateRing(100);
      state.busy = false;
      setBusy(false);
      renderSysUpdates(state.updates || {});
      if (ok) {
        const last = st.lines[st.lines.length - 1] || "";
        statusCard(tr("status.updated"), last, "done");
        toast(tr("toast.successUpdate"), "succ");
        setTimeout(() => {
          $("#install-status").hidden = true;
          $("#modal").hidden = true;
        }, 4200);
        checkSystemUpdates();
      } else {
        const last = st.lines[st.lines.length - 1] || "";
        statusCard(tr("status.failUpdate"), last, "error");
        toast(tr("toast.failUpdate"), "err");
        setTimeout(() => { $("#install-status").hidden = true; }, 4200);
      }
    }
  })();
}

function bindGlobal() {
  blockContextMenu();
  $("#store-info").addEventListener("click", openStoreInfo);
  
  const sysUpdBadge = $("#sysupd-badge");
  if (sysUpdBadge) {
    sysUpdBadge.addEventListener("click", openSysUpdatesModal);
    sysUpdBadge.style.cursor = "pointer";
  }
  
  window.addEventListener("online", renderNet);
  window.addEventListener("offline", renderNet);
  renderNet();

  const toTop = $("#to-top");
  const topbar = $("#topbar");
  if (toTop && topbar) {
    toTop.addEventListener("click", () =>
      window.scrollTo({ top: 0, behavior: "smooth" }));
    if (typeof IntersectionObserver === "function") {
      new IntersectionObserver(
        ([entry]) => toTop.classList.toggle("show", !entry.isIntersecting),
        { threshold: 0 }
      ).observe(topbar);
    } else {
      const onScroll = () =>
        toTop.classList.toggle("show", window.scrollY > 140);
      window.addEventListener("scroll", onScroll, { passive: true });
      onScroll();
    }
  }

  $("#search").addEventListener("input", (ev) => {
    const esc2 = ev.target.value;
    clearTimeout(state._dt);
    state._dt = setTimeout(() => { state.q = esc2; render(false); }, 120);
  });

  // External links: open in the system browser (works inside the native WebView).
  document.addEventListener("click", (ev) => {
    const a = ev.target.closest("a[target=_blank]");
    if (a && window.pywebview && window.pywebview.api
        && typeof window.pywebview.api.open_external === "function"
        && a.href && /^https?:/i.test(a.href)) {
      ev.preventDefault();
      window.pywebview.api.open_external(a.href);
    }
  });
  document.addEventListener("submit", (ev) => {
    if (ev.target.matches("[data-job-reply]")) sendJobReply(ev);
  });

  document.addEventListener("keydown", (ev) => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(ev.target.tagName);
    if (ev.key === "/" && !typing && !$("#lightbox").hidden) return;
    if (ev.key === "/" && !typing) {
      ev.preventDefault();
      $("#search").focus();
    }
    if (ev.key === "Escape") {
      if (!$("#lightbox").hidden) closeLightbox();
      else if (!$("#modal").hidden) $("#modal").hidden = true;
    }
    if ($("#lightbox").hidden) return;
    if (ev.key === "ArrowRight") lbStep(1);
    if (ev.key === "ArrowLeft") lbStep(-1);
  });

  $$(".modal").forEach((m) => m.addEventListener("click", (ev) => {
    if (ev.target.closest("[data-close]")) m.hidden = true;
  }));
  $$(".lightbox").forEach((lb) => lb.addEventListener("click", (ev) => {
    if (ev.target.closest("[data-close]") || ev.target.closest("#lightbox-img") || ev.target.id === "lightbox") closeLightbox();
  }));
  $("#lb-prev").addEventListener("click", (ev) => { ev.stopPropagation(); lbStep(-1); });
  $("#lb-next").addEventListener("click", (ev) => { ev.stopPropagation(); lbStep(1); });
  $("#status-close").addEventListener("click", () => { $("#install-status").hidden = true; });
}

function closeLightbox() {
  $("#lightbox").hidden = true;
}

/* ============================== Tooltips ================================= */
function setupTips() {
  const layer = document.createElement("div");
  layer.id = "tip-layer";
  document.body.appendChild(layer);

  let tipEl = null, timer = null;

  function showTip(el) {
    const text = el.getAttribute("data-tip");
    if (!text) { hideTip(); return; }
    if (!tipEl) {
      tipEl = document.createElement("div");
      tipEl.className = "js-tip";
      layer.appendChild(tipEl);
    }
    tipEl.textContent = text;
    tipEl.style.left = "0px";
    tipEl.style.top = "0px";
    tipEl.style.opacity = "0";
    const r = el.getBoundingClientRect();
    const tw = tipEl.offsetWidth;
    const th = tipEl.offsetHeight;
    let left = Math.round(r.left + r.width / 2 - tw / 2);
    left = Math.max(8, Math.min(left, window.innerWidth - tw - 8));
    let top = Math.round(r.bottom + 8);
    if (top + th > window.innerHeight - 8) top = Math.round(r.top - th - 8);
    tipEl.style.left = left + "px";
    tipEl.style.top = top + "px";
    requestAnimationFrame(() => { if (tipEl) tipEl.classList.add("on"); });
  }

  function hideTip() {
    clearTimeout(timer);
    if (tipEl) {
      tipEl.classList.remove("on");
      const dead = tipEl;
      tipEl = null;
      setTimeout(() => dead.remove(), 200);
    }
  }

  document.addEventListener("mouseover", (e) => {
    const el = e.target && e.target.closest ? e.target.closest("[data-tip]") : null;
    clearTimeout(timer);
    if (el) timer = setTimeout(() => showTip(el), 50);
    else hideTip();
  });
  document.addEventListener("scroll", hideTip, true);
}

/* ============================== Boot ===================================== */

/* O clique direito fica desativado: o menu do WebKit traz recarregar,
   inspecionar e "abrir com", que não fazem sentido numa loja de sistema. */
function blockContextMenu() {
  document.addEventListener("contextmenu", (e) => e.preventDefault());
  window.addEventListener("contextmenu", (e) => e.preventDefault());
}

/* Diff entre dois catálogos: o que entrou, o que saiu e o que mudou. */
function diffCatalog(antes, agora) {
  const A = new Map((antes.products || []).map((p) => [p.key, p]));
  const B = new Map((agora.products || []).map((p) => [p.key, p]));
  const novos = [], removidos = [], alterados = [];
  B.forEach((p, k) => {
    const velho = A.get(k);
    if (!velho) { novos.push(p); return; }
    /* Compara o registro inteiro, e não o HTML do card: o card mostra só um
       trecho da descrição, então resumo, pacote, ícone ou link alterados
       continuariam invisíveis para a tela (e para o aviso). */
    if (JSON.stringify(p) !== JSON.stringify(velho)) {
      alterados.push({ agora: p, antes: velho });
    }
  });
  A.forEach((p, k) => { if (!B.has(k)) removidos.push(p); });
  return { novos, removidos, alterados };
}

/* Assinatura de um card. Compara o registro inteiro, e não o HTML: o card
   mostra só um trecho da descrição, então comparar o HTML deixaria passar
   mudança de resumo ou de qualquer campo fora do trecho. */
function cardSig(p) {
  return JSON.stringify(p);
}

/* Atualiza a grade sem recarregar a janela: cada card que não mudou continua
   exatamente onde está (mesmo elemento, mesma posição), então a tela não pisca.
   Só entram os cards novos e saem os removidos. */
function patchGrid() {
  const grid = $("#grid");
  const products = visibleProducts();
  const querer = new Set(products.map((p) => p.key));
  grid.querySelectorAll(".card").forEach((c) => {
    if (!querer.has(c.dataset.key)) c.remove();
  });
  let anterior = null;
  products.forEach((p, i) => {
    const sig = cardSig(p);
    let el = grid.querySelector(`.card[data-key="${cssEsc(p.key)}"]`);
    /* Card novo ou card cujo conteúdo mudou: troca o elemento inteiro. Montar
       o HTML dentro do card antigo criaria um <article> dentro do outro. */
    if (!el || (state.cardSig || new Map()).get(p.key) !== sig) {
      const tpl = document.createElement("template");
      tpl.innerHTML = cardHtml(p, i).trim();
      const novo = tpl.content.firstElementChild;
      if (el) {
        /* Card trocido porque mudou: entra sem a animação de entrada, senão a
           tela pisca como se tivesse recarregado. Só card novo anima. */
        novo.classList.add("no-anim");
        el.replaceWith(novo);
      }
      el = novo;
    }
    const alvo = anterior ? anterior.nextSibling : grid.firstChild;
    if (alvo !== el) grid.insertBefore(el, alvo);
    anterior = el;
  });
  state.cardSig = new Map(products.map((p) => [p.key, cardSig(p)]));
  grid.querySelectorAll("img").forEach((img) => mountIcon(img, img.dataset.fb));
  $("#installed-filter-count").textContent =
    state.data.products.filter((p) => p.installed).length;
  $("#results-count").textContent = tr("results.count", products.length, state.data.total);
  $("#empty").hidden = products.length > 0;
}

/* Escuta o servidor: quando o catálogo muda, aplica só o que mudou e avisa.
   Não existe location.reload() em lugar nenhum — a janela nunca recarrega. */
function applyFresh(fresh, silencioso, forcar) {
  const antes = state.data;
  if (!antes) { state.data = fresh; renderHeader(fresh); renderCats(fresh.categories); render(); return; }

  const revAntes = (antes.store || {}).revision, revAgora = (fresh.store || {}).revision;
  const updAntes = (antes.store || {}).updated, updAgora = (fresh.store || {}).updated;

  /* Cabeçalho e contadores são baratos: mudam sempre que o servidor mudou. */
  if (revAntes !== revAgora || updAntes !== updAgora) {
    renderRevBadge(fresh);
    renderStoreMeta(fresh);
    $("#foot-info").textContent = tr("foot.apps", fresh.total);
    const ab = $("#admin-badge");
    if (ab) ab.hidden = !fresh.admin;
    const al = $("#admin-link");
    if (al) al.hidden = !fresh.admin;
  }

  const hashAntes = antes.stats && antes.stats.catalog_hash;
  const hashAgora = fresh.stats && fresh.stats.catalog_hash;
  /* A base do diff tem de ser o payload mais recente, mesmo quando não entra
     nenhum card novo: senão o próximo poll compara sempre com a mesma versão. */
  if (!hashAgora || hashAgora === hashAntes) {
    /* O catálogo é o mesmo, mas o que está instalado pode ter mudado (a loja
       acabou de instalar ou desinstalar). O hash não cobre isso, então sem esta
       conferência o app desinstalado continuaria marcado como instalado até a
       próxima mudança de catálogo. */
    const antesInstalado = new Map((antes.products || []).map((p) => [p.key, p.installed]));
    const mudou = (fresh.products || []).some((p) => antesInstalado.get(p.key) !== p.installed)
      || antesInstalado.size !== (fresh.products || []).length;
    state.data = fresh;
    /* `forcar` é o caso de instalar/desinstalar: aqui o estado local já foi
       mexido à mão e por isso a comparação diz que "não mudou", mas o card na
       tela continua com o botão antigo. O patch compara com a assinatura da
       última renderização, então ele troca o card certo. */
    if (!mudou && !forcar) return;
    renderCats(fresh.categories);
    patchGrid();
    return;
  }

  const d = diffCatalog(antes, fresh);
  if (antes.total === fresh.total &&
      JSON.stringify(antes.categories) === JSON.stringify(fresh.categories) &&
      !d.novos.length && !d.removidos.length && !d.alterados.length) {
    state.data = fresh;
    return;
  }

  state.data = fresh;
  renderCats(fresh.categories);
  patchGrid();

  const partes = [];
  if (d.novos.length) partes.push(tr(d.novos.length === 1 ? "upd.new.one" : "upd.new", d.novos.length));
  if (d.removidos.length) partes.push(tr(d.removidos.length === 1 ? "upd.gone.one" : "upd.gone", d.removidos.length));
  if (d.alterados.length) partes.push(tr(d.alterados.length === 1 ? "upd.changed.one" : "upd.changed", d.alterados.length));
  const titulo = tr("upd.toast", revAgora == null ? "?" : revAgora);
  /* `silencioso` é quando a própria loja causou a mudança (instalar ou
     desinstalar): o aviso de catálogo seria enganoso. */
  if (!silencioso) toast(partes.length ? `${titulo} · ${partes.join(" · ")}` : titulo, "upd", 6000);
}

/* Depois de instalar ou desinstalar, o "instalado" só vale se o servidor
   confirmar agora: o estado guardado aqui era uma aposta e o poll seguinte
   sobrescrevia com o do servidor. Buscar de verdade também evita refazer a
   tela inteira, que fazia a loja piscar como se tivesse recarregado. */
async function conferirDoServidor(product) {
  try {
    applyFresh(await api("/api/index"), true, true);
  } catch (e) {
    render(false);
  }
  /* O modal nao e reconstruido pelo patch, entao os botoes dele ficariam com o
     estado antigo (instalar um app deixaria "Instalar" em vez de "Remover"). */
  if (product && !$("#modal").hidden) {
    const box = $("#modal-content .m-actions");
    if (box) {
      const atual = fromKey(product.key);
      box.innerHTML = modalActionsHtml(atual || product);
      bindModalActions();
    }
  }
}

function watchRevision() {
  setInterval(async () => {
    if (state.busy) return;
    try {
      const resp = await fetch("/api/index", { cache: "no-store" });
      applyFresh(await resp.json());
    } catch (e) { /* offline momentâneo */ }
  }, 4000);
}

/* Badge de atualizações do sistema no cabeçalho. Diz quantos pacotes têm
   versão nova e o total que seria baixado. O total só aparece quando todos os
   pacotes da lista têm tamanho conhecido — somar só os que sabemos deixaria
   o número abaixo do real, que é pior do que não mostrar. */
function renderSysUpdates(d) {
  const el = $("#sysupd-badge");
  if (!el) return;
  const total = (d && d.total) || 0;
  if (!total) { el.hidden = true; el.textContent = ""; return; }
  const completo = d.sized === total && d.total_bytes;
  const tip = completo
    ? tr("sysupd.tipFull", total, fmtBytes(d.total_bytes))
    : tr("sysupd.tipPartial", total, d.sized || 0);
  el.innerHTML =
    `<i class="ti ti-refresh"></i><span class="su-n">${total}</span>` +
    (completo ? `<span class="su-b">${esc(fmtBytes(d.total_bytes))}</span>` : "");
  el.dataset.tip = tip;
  el.hidden = false;
}

function renderSysUpdateProgress(progress) {
  const el = $("#sysupd-badge");
  if (!el) return;
  const label = tr("sysupd.progress", Number.isFinite(progress) ? progress : 0);
  const icon = document.createElement("i");
  icon.className = "ti ti-refresh";
  const text = document.createElement("span");
  text.textContent = label;
  el.replaceChildren(icon, text);
  el.dataset.tip = label;
  el.hidden = false;
  tweenSysUpdateRing(progress);
}

/* Versões dos programas: o servidor pergunta ao pacman (com cache, porque a
   consulta é mais cara que a do catálogo) e a tela avisa no canto quando
   aparece versão nova. Endpoint ausente em versões antigas: silêncio. */
/* Os pacotes do Arch já vêm decididos no payload, porque o verificador local
   (`pacman_db`) é o mesmo que monta o payload. Os da AUR não: exigiriam uma
   consulta à rede dentro do `build_payload`, que roda no boot e a cada
   salvamento da curadoria — 6 s de espera quando está sem rede.

   Por isso a AUR é conferida aqui, depois de a loja já estar na tela: uma
   consulta só, cujo resultado marca `aur_missing` nos produtos. Se a consulta
   falhar, nada muda — os apps AUR seguem sem chip, que é a posição honesta
   quando não se sabe. */
async function checkBrokenAUR() {
  let d;
  try {
    d = await api("/api/broken");
  } catch (_) {
    return;                       // sem rede: nenhum chip novo
  }
  const aur = {};
  for (const a of d.apps || []) {
    if (a.source === "aur") aur[a.id] = a;
  }
  const semConf = new Set((d.sem_conferencia || []).map((a) => a.id));
  let mudou = false;
  for (const p of (state.data && state.data.products) || []) {
    const quebrado = aur[p.id];
    const alvo = !!quebrado;
    if (!!p.aur_missing !== alvo) {
      p.aur_missing = alvo;
      mudou = true;
    }
    // Não conferido não vira quebrado: o card fica sem chip, que é o mesmo
    // tratamento do payload para os apps AUR.
    if (semConf.has(p.id)) p.aur_unverified = true;
  }
  if (mudou) render();
}

/* A AUR muda sozinha (um pacote sai de lá sem aviso). Reconsultar de vez em
   quando faz o aviso aparecer sem precisar recarregar a loja inteira. */
function watchBrokenAUR() {
  setInterval(() => { checkBrokenAUR(); }, 15 * 60 * 1000);
}

async function checkSystemUpdates() {
  try {
    const resp = await fetch("/api/updates", { cache: "no-store" });
    if (!resp.ok) return;
    const d = await resp.json();
    state.updates = d;
    const total = d.total || 0;
    renderSysUpdates(d);
  } catch (e) { /* sem endpoint ou offline: não é motivo para incomodar */ }
}

function watchUpdates() {
  let anterior = null;
  const checar = async () => {
    if (state.busy) return;
    try {
      const resp = await fetch("/api/updates", { cache: "no-store" });
      if (!resp.ok) return;
      const d = await resp.json();
      state.updates = d;
      const total = d.total || 0;
      renderSysUpdates(d);
      if (anterior !== null && total > anterior) {
        toast(tr(total === 1 ? "upd.pkg.one" : "upd.pkg", total), "upd", 6000);
      }
      anterior = total;
    } catch (e) { /* sem endpoint ou offline: não é motivo para incomodar */ }
  };
  setTimeout(checar, 6000);
  setInterval(checar, 60000);
}

async function boot() {
  try {
    applyStatic();
    themeInit();
    skeletonCards();
    const data = await api("/api/index");
    state.data = data;
    renderHeader(data);
    renderCats(data.categories);
    render();
    bindDelegates();
    bindModalActions();
    bindGlobal();
    setupTips();
    watchRevision();
    watchUpdates();
    checkBrokenAUR();
    watchBrokenAUR();
  } catch (e) {
    console.error(e);
    $("#grid").innerHTML = "";
    $("#empty").hidden = false;
    $("#empty h2").textContent = tr("err.load");
    $("#empty p").textContent = tr("err.checkServer");
    toast(tr("toast.loadFail"), "err");
  }
}

boot();